package com.Calculator.SeviceIpml;

import org.springframework.stereotype.Service;

import com.Calculator.Model.Calculator;
import com.Calculator.Service.CalcultorService;

@Service
public class CalculatorSeviceImpl implements CalcultorService{

	
	
	@Override
	public Calculator add(double previousNumber, double currentNumber) {
		
		return new Calculator(previousNumber,currentNumber,previousNumber+currentNumber);
	}

	@Override
	public Calculator sub(double previousNumber, double currentNumber) {
		// TODO Auto-generated method stub
		return new Calculator(previousNumber,currentNumber,previousNumber-currentNumber);
	}

	@Override
	public Calculator mul(double previousNumber, double currentNumber) {
		// TODO Auto-generated method stub
		return new Calculator(previousNumber,currentNumber,previousNumber*currentNumber);
	}

	@Override
	public Calculator subt(double previousNumber, double currentNumber) {
		// TODO Auto-generated method stub
		return new Calculator(previousNumber,currentNumber,previousNumber/currentNumber);
	}

	


	
	
}

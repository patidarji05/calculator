import Calculator from "./styles/Calculator";
function App() {
  return (
    <div className="App">

      <Calculator />
    </div>
  );
}

export default App;
